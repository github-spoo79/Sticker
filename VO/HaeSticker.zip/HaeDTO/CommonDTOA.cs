﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaeDTO
{
    public class CommonDTOA
    {
        List<CommonDTO> dtoa = new List<CommonDTO>();

        public int size()
        {
            return dtoa.Count;
        }

        public void add(CommonDTO o)
        {
            dtoa.Add(o);
        }

        public CommonDTO get(int i)
        {
            return dtoa[i];
        }

        public void remove(int i)
        {
            dtoa.RemoveAt(i);
        }
    }
}
