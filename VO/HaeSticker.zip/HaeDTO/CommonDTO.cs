﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaeDTO
{
    public class CommonDTO
    {
        private Dictionary<string, object> commonDTO = null;

        public CommonDTO()
        {
            commonDTO = new Dictionary<string, object>();
        }

        public object get(string key)
        {
            return commonDTO[key];
        }

        public void set(string key, object value)
        {
            if (commonDTO.ContainsKey(key))
            {
                commonDTO[key] = value;
            }
            else
            {
                commonDTO.Add(key, value);
            }
        }

        public Boolean isExists(string key)
        {
            return commonDTO.ContainsKey(key);
        }

        public void remove(string key)
        {
            commonDTO.Remove(key);
        }

        public int size() 
        {
            return commonDTO.Count;
        }

        public string getKeys(int idx)
        {
            return commonDTO.Keys.ToList()[idx];
        }
    }
}
