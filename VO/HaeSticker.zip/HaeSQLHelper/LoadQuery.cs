﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace HaeSQLHelper
{
    public class LoadQuery
    {
        XmlDocument doc = new XmlDocument();

        public LoadQuery()
        {
            doc.Load("SQLQuery.xml");
        }

        public LoadQuery(string path)
        {
            doc.Load(path);
        }

        public string getQuery(string id)
        {
            string sqlQuery = string.Empty;
            try
            {
                sqlQuery = doc.SelectSingleNode("//*[@id='" + id + "']").InnerText;
            }
            catch (Exception)
            {
            }
            return sqlQuery;
        }
    }
}
