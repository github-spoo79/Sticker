﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using HaeDTO;

namespace HaeSQLHelper
{
    public class SQLAccess
    {
        SqlConnection conn = null;

        public SQLAccess()
        {
            conn = new SqlConnection();
            conn.ConnectionString = "Data Source=hdsql2005;Initial Catalog=AQIS;User ID=aqisuser;Password=aqis!@746";
        }

        public SQLAccess(string connectionInfo)
        {
            conn = new SqlConnection();
            conn.ConnectionString = connectionInfo;
            //conn.ConnectionString = "Data Source=hdsql2005;Initial Catalog=AQIS;User ID=aqisuser;Password=aqis!@746";            
        }

        public DataTable select(string sql)
        {
            DataSet ds = new DataSet();
            try
            {
                conn.Open();
                //SqlCommand sqlCmd = conn.CreateCommand();
                //sqlCmd.CommandText = sql;
                //SqlDataReader reader = sqlCmd.ExecuteReader();
                //dt.Load(reader);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                adapter.Fill(ds);                
            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return ds.Tables[0];
        }

        public DataTable select(string sql, CommonDTO dto)
        {
            DataSet ds = new DataSet();
            try
            {
                conn.Open();
                SqlCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;

                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }

                SqlDataAdapter adapter = new SqlDataAdapter(sqlCmd);
                adapter.Fill(ds);
            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return ds.Tables[0];
        }

        public int execute(string sql, CommonDTO dto)
        {
            int cnt = 0;
            try
            {
                conn.Open();
                SqlCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;
                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }
                cnt = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return cnt;
        }

        /* insert, update, delete method execute 로 통합  */
        /*
        public int insert(string sql, CommonDTO dto)
        {
            int cnt = 0;
            try
            {
                conn.Open();
                SqlCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;
                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }
                cnt = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return cnt;
        }

        public int update(string sql, CommonDTO dto)
        {
            int cnt = 0;
            try
            {
                conn.Open();
                SqlCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;
                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }
                cnt = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return cnt;
        }

        public int delete(string sql, CommonDTO dto)
        {
            int cnt = 0;
            try
            {
                conn.Open();
                SqlCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;
                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }
                cnt = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return cnt;
        }*/        
    }
}
