﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.SQLite;
using HaeDTO;


namespace HaeSQLHelper
{    
    public class SQLiteAccess
    {
        private SQLiteConnection conn = null;

        public SQLiteAccess()
        {
            conn = new SQLiteConnection("Data Source=d:\\test.db;Version=3;");
            //conn.ConnectionString = "Data Source=d:\test.db";
        }

        public SQLiteAccess(string connectionInfo)
        {
            conn = new SQLiteConnection("Data Source=" + connectionInfo + ";Version=3;");
            //conn.ConnectionString = @"Data Source=" + connectionInfo;
        }

        public DataTable select(string sql)
        {
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SQLiteCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                dt.Load(reader);
            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        public DataTable select(string sql, CommonDTO dto)
        {
            DataTable dt = new DataTable();
            try
            {
                conn.Open();
                SQLiteCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;
                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                dt.Load(reader);
            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        public int execute(string sql, CommonDTO dto)
        {
            int cnt = 0;
            try
            {
                conn.Open();
                SQLiteCommand sqlCmd = conn.CreateCommand();
                sqlCmd.CommandText = sql;
                string columnName = string.Empty;
                for (int idx = 0; idx < dto.size(); idx++)
                {
                    columnName = dto.getKeys(idx);
                    sqlCmd.Parameters.AddWithValue("@" + columnName, dto.get(columnName));
                }
                cnt = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
            }
            finally
            {
                conn.Close();
            }
            return cnt;
        }
    }
}
