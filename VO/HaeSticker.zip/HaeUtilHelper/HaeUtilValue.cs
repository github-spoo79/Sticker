﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace HaeUtilHelper
{
    public class HaeUtilValue
    {
        public int ToIntNullZero(object o)
        {
            int returnValue = 0;
            try
            {
                returnValue = Int32.Parse(o.ToString());
            }
            catch
            {
            }           
            return returnValue;
        }

        public int ToIntNullDefault(object o, int defaultValue)
        {
            int returnValue = defaultValue;
            try
            {
                returnValue = Int32.Parse(o.ToString());
            }
            catch
            {
            }            
            return returnValue;
        }

        public string ToStringNullEmpty(object o)
        {
            string returnValue = string.Empty;
            try
            {
                returnValue = o.ToString();
            }
            catch
            {
            }
            return returnValue;
        }

        public string ToStringNullDefault(object o, string defaultValue)
        {
            string returnValue = defaultValue;
            try
            {
                returnValue = o.ToString();
            }
            catch
            {
            }
            return returnValue;
        }
    }
}
