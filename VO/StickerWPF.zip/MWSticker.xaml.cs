﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StickerWPF
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MWSticker : Window
    {
        private Boolean showEnv = false;

        private Boolean folded = false;        
        private Boolean bolded = false;
        private Boolean italic = false;        
        private Boolean strike = false;        
        private Boolean unfixed = true;
        private Boolean underline = false;

        private double previousHeight;

        public MWSticker()
        {
            InitializeComponent();

            initControl();
        }

        private void initControl()
        {
            cmbFontSize.ItemsSource = createComboFontSize();
            cmbFontSize.DisplayMemberPath = "NAME";
            cmbFontSize.SelectedValuePath = "VALUE";
        }

        private DataView createComboFontSize()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("VALUE", typeof(string));
            dt.Columns.Add("NAME", typeof(string));

            dt.Rows.Add(new string[] { "8", "8" });
            dt.Rows.Add(new string[] { "9", "9" });
            dt.Rows.Add(new string[] { "10", "10" });
            dt.Rows.Add(new string[] { "11", "11" });
            dt.Rows.Add(new string[] { "12", "12" });
            dt.Rows.Add(new string[] { "14", "14" });
            dt.Rows.Add(new string[] { "16", "16" });
            dt.Rows.Add(new string[] { "18", "18" });
            dt.Rows.Add(new string[] { "24", "24" });
            dt.Rows.Add(new string[] { "32", "32" });
            return dt.DefaultView;
        }

        #region  event handler

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cmbFont.SelectedIndex = 0;
            cmbFontSize.SelectedIndex = 2;
            rtbContent.Focus();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void lblTitle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (unfixed)
                {
                    this.DragMove();
                }                
            }
        }

        private void btnEnv_Click(object sender, RoutedEventArgs e)
        {
            if (showEnv)
            {
                rowEnv.Height = new GridLength(0);
                showEnv = false;
            }
            else
            {
                rowEnv.Height = new GridLength(48);
                showEnv = true;
            }
        }

        private void btnExpand_Click(object sender, RoutedEventArgs e)
        {
            if (folded)
            {
                this.tbTitle.SetValue(Grid.ColumnSpanProperty, 1);
                this.lblTitle.SetValue(Grid.ColumnSpanProperty, 1);
                this.btnEnv.Visibility = Visibility.Visible;
                this.ResizeMode = ResizeMode.CanResizeWithGrip;
                this.MinHeight = 150;
                this.Height = previousHeight;
                folded = false;
            }
            else
            {
                this.tbTitle.SetValue(Grid.ColumnSpanProperty, 2);
                this.lblTitle.SetValue(Grid.ColumnSpanProperty, 2);
                this.btnEnv.Visibility = Visibility.Hidden;
                previousHeight = this.Height;
                this.ResizeMode = ResizeMode.NoResize;
                this.MinHeight = 24;
                this.Height = 24;
                folded = true;
            }
        }

        private void lblTitle_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            tbTitle.Visibility = Visibility.Visible;
            lblTitle.Visibility = Visibility.Hidden;
            tbTitle.Focus();
        }

        private void tbTitle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                lblTitle.Content = tbTitle.Text.ToString();
                tbTitle.Visibility = Visibility.Hidden;
                lblTitle.Visibility = Visibility.Visible;
            }
        }

        private void tbTitle_LostFocus(object sender, RoutedEventArgs e)
        {
            lblTitle.Content = tbTitle.Text.ToString();
            tbTitle.Visibility = Visibility.Hidden;
            lblTitle.Visibility = Visibility.Visible;
        }

        private void rtbContent_KeyDown(object sender, KeyEventArgs e)
        {
            //rowEnv.Height = new GridLength(48);
        }

        private void rtbContent_LostFocus(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
        }

        private void cmbFont_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            setRtfContentFontFamilyAndSize();
        }

        private void cmbFontSize_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            setRtfContentFontFamilyAndSize();
        }

        private void ImgBtnBold_MouseDown(object sender, MouseButtonEventArgs e)
        {
            setRtfContentFontStyle("bold");
        }

        private void ImgBtnItalic_MouseDown(object sender, MouseButtonEventArgs e)
        {
            setRtfContentFontStyle("italic");
        }

        private void ImgBtnUnderLine_MouseDown(object sender, MouseButtonEventArgs e)
        {
            setRtfContentFontStyle("underline");
        }

        private void ImgBtnStrikeThrough_MouseDown(object sender, MouseButtonEventArgs e)
        {
            setRtfContentFontStyle("strike");
        }

        private void rtbContent_SelectionChanged(object sender, RoutedEventArgs e)
        {
            btnBold.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
            btnItalic.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
            btnUnderLine.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
            btnStrike.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
            bolded = false;
            italic = false;            
            strike = false;
            underline = false;
        }

        private void ImgBtnClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Close();
        }

        private void ImgBtnAdd_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MWSticker mwSticker = new MWSticker();
            mwSticker.Show();
        }

        private void btnFixed_Click(object sender, RoutedEventArgs e)
        {
            if (unfixed)
            {
                imgFixed.Source = new BitmapImage(new Uri(@"Resources/btnFixed.png", UriKind.Relative));
                unfixed = false;
            }
            else
            {
                imgFixed.Source = new BitmapImage(new Uri(@"Resources/btnFix.png", UriKind.Relative));
                unfixed = true;
            }
        }

        private void btnTxtFontColor_Click(object sender, RoutedEventArgs e)
        {
            Window mwColorPicker = new Window();
            MWColorPicker ucMWColorPicker = new MWColorPicker();
            ucMWColorPicker.MwSticker = (MWSticker)Window.GetWindow(this);
            mwColorPicker.Content = ucMWColorPicker;
            var location = btnTxtFontColor.PointToScreen(new Point(0, 0));
            mwColorPicker.Left = location.X;
            mwColorPicker.Top = location.Y + btnTxtFontColor.Height;
            mwColorPicker.WindowStyle = WindowStyle.None;
            mwColorPicker.ResizeMode = ResizeMode.NoResize;
            mwColorPicker.Width = 128;
            mwColorPicker.Height = 48;
            mwColorPicker.Topmost = true;
            mwColorPicker.Show();
        }
        #endregion

        public void setTxtFontColor(string fontColor)
        {
            SolidColorBrush foreColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString(fontColor));
            recTxtFontColor.Fill = foreColor;

            if (rtbContent.Selection != null)
            {
                if (rtbContent.Selection.IsEmpty)
                {
                    Run run = new Run(String.Empty, rtbContent.CaretPosition);
                    run.Foreground = recTxtFontColor.Fill;
                    //run.FontSize = double.Parse((String)cmbFontSize.Items.GetItemAt(cmbFontSize.SelectedIndex));
                    rtbContent.Focus();
                }
                else
                {
                    TextRange range = new TextRange(rtbContent.Selection.Start, rtbContent.Selection.End);
                    range.ApplyPropertyValue(ForegroundProperty, foreColor);
                }
            }
        }

        private void setRtfContentFontFamilyAndSize()
        {
            if (rtbContent.Selection != null)
            {
                if (rtbContent.Selection.IsEmpty)
                {
                    Run run = new Run(String.Empty, rtbContent.CaretPosition);
                    //run.Foreground = recTxtFontColor.Fill;
                    //run.FontFamily = (FontFamily)cmbFont.SelectedItem.ToString();
                    //run.FontSize = double.Parse((String)cmbFontSize.Items.GetItemAt(cmbFontSize.SelectedIndex));
                    rtbContent.Focus();
                }
                else
                {
                    TextRange range = new TextRange(rtbContent.Selection.Start, rtbContent.Selection.End);
                    range.ApplyPropertyValue(TextElement.FontFamilyProperty, cmbFont.SelectedItem.ToString());
                    range.ApplyPropertyValue(TextElement.FontSizeProperty, ((DataRowView)cmbFontSize.Items.GetItemAt(cmbFontSize.SelectedIndex)).Row.ItemArray[0].ToString());
                }
            }
            rtbContent.Focus();
        }

        private void setRtfContentFontStyle(string style)
        {
            if (rtbContent.Selection != null)
            {
                if (rtbContent.Selection.IsEmpty)
                {
                    return;
                }
                else
                {
                    TextRange range = new TextRange(rtbContent.Selection.Start, rtbContent.Selection.End);
                    switch (style)
                    {                        
                        case "bold":                            
                            if (bolded)
                            {
                                range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
                                btnBold.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
                                bolded = false;
                            }
                            else
                            {
                                range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                                btnBold.Background = (SolidColorBrush)Application.Current.FindResource("btnMouseover");
                                bolded = true;
                            }
                            break;
                        case "italic":
                            if (italic)
                            {
                                range.ApplyPropertyValue(TextElement.FontStyleProperty, FontStyles.Normal);
                                btnItalic.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
                                italic = false;
                            }
                            else
                            {
                                range.ApplyPropertyValue(TextElement.FontStyleProperty, FontStyles.Italic);
                                btnItalic.Background = (SolidColorBrush)Application.Current.FindResource("btnMouseover");
                                italic = true;
                            }
                            break;
                        case "underline":
                            if (underline)
                            {
                                TextDecorationCollection underLineDeco = (TextDecorationCollection)rtbContent.Selection.GetPropertyValue(Inline.TextDecorationsProperty);
                                if (underLineDeco.Contains(TextDecorations.Underline[0]))
                                {
                                    TextDecorationCollection noUnderlineDeco = new TextDecorationCollection(underLineDeco);
                                    noUnderlineDeco.Remove(TextDecorations.Underline[0]);  //this is a bool, and could replace Contains above
                                    rtbContent.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty, noUnderlineDeco);
                                }
                                //range.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Underline);
                                btnUnderLine.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
                                underline = false;
                            }
                            else
                            {                                
                                range.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Underline);
                                btnUnderLine.Background = (SolidColorBrush)Application.Current.FindResource("btnMouseover");
                                underline = true;

                                //Strike 와 Underline 동시에 적용이 안되기 때문에 한쪽은 강제 해제
                                btnStrike.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
                                strike = false;
                            }
                            break;
                        case "strike":
                            if (strike)
                            {
                                TextDecorationCollection strikeDeco = (TextDecorationCollection)rtbContent.Selection.GetPropertyValue(Inline.TextDecorationsProperty);
                                if (strikeDeco.Contains(TextDecorations.Strikethrough[0]))
                                {
                                    TextDecorationCollection noStikeDeco = new TextDecorationCollection(strikeDeco);
                                    noStikeDeco.Remove(TextDecorations.Strikethrough[0]);  //this is a bool, and could replace Contains above
                                    rtbContent.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty, noStikeDeco);
                                }
                                btnStrike.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
                                strike = false;
                            }
                            else
                            {                                
                                range.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Strikethrough);
                                btnStrike.Background = (SolidColorBrush)Application.Current.FindResource("btnMouseover");                                
                                strike = true;

                                //Strike 와 Underline 동시에 적용이 안되기 때문에 한쪽은 강제 해제
                                btnUnderLine.Background = (SolidColorBrush)Application.Current.FindResource("btnBackground");
                                underline = false;
                            }
                            break;
                    }

                }
            }
            rtbContent.Focus();
        }

        private void rtbContent_MouseLeave(object sender, MouseEventArgs e)
        {
            //rowEnv.Height = new GridLength(0);
        }

        private void btnUpDown_MouseDown(object sender, MouseButtonEventArgs e)
        {
            
        }

        private void btnUpDown_Click(object sender, RoutedEventArgs e)
        {
            if (showEnv)
            {
                rowEnv.Height = new GridLength(0);
                showEnv = false;
            }
            else
            {
                rowEnv.Height = new GridLength(48);
                showEnv = true;
            }
        }
    }
}
